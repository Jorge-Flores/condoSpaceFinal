package com.example.condospace2;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btEntrar;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        criarEstruturaDados();

        btEntrar = findViewById(R.id.btEntrar);
            btEntrar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View argsO) {
                Intent menuActivity = new Intent(MainActivity.this, MenuActivity.class);
                MainActivity.this.startActivity(menuActivity);
                }
            });
    }
    private void criarEstruturaDados() {
        try {
            db = openOrCreateDatabase("BD_CONDO_SPACE_APP", Context.MODE_PRIVATE, null);
            db.execSQL("create table if not exists agendamento (cod_agendamento integer primary key autoincrement, nome_local text not null, nome_responsavel text not null,  data_inicio date not null, data_final date  not null, num_pessoas int not null) ");

        } catch (Exception e) {

        }
    }
}
