package com.example.condospace2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class InserirAgedamentoActivity extends AppCompatActivity {
    Button btSalvar , btVoltar;
    EditText txtLocal, txtResponsavel, txtDataInicio, txtDataFinal, txtNumPessoas;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inserir_agedamento);

        txtLocal= findViewById(R.id.txtLocal);
        txtResponsavel = findViewById(R.id.txtResponsavel);
        txtDataFinal = findViewById(R.id.txtDataFinal);
        txtDataInicio = findViewById(R.id.txtDatainicio);

        btSalvar = findViewById(R.id.btSalvar);
        btVoltar = findViewById(R.id.btVoltar);

        btSalvar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                String nome = txtLocal.getText().toString();
                String responsavel = txtResponsavel.getText().toString();
                String dataInicial = txtDataInicio.getText().toString();
                String dataFinal = txtDataFinal.getText().toString();
                String numPessoas = txtNumPessoas.getText().toString();

                ContentValues objeto = new ContentValues();
                objeto.put("nome_local", nome);
                objeto.put("nome_responsavel", responsavel);
                objeto.put("data_inicio", dataInicial);
                objeto.put("data_final", dataFinal);
                objeto.put("num_pessoas", numPessoas);

                try {
                    db = openOrCreateDatabase("BD_CONDO_SPACE_APP", Context.MODE_PRIVATE, null);
                    db.insert("agendamento", null, objeto);
                    mostraMensagem("Dados Cadastrados  com sucesso!");
                } catch (Exception e) {
                    mostraMensagem("erro" + e.toString());
                }
            }
        });
        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InserirAgedamentoActivity.this.finish();
            }
        });
    }
    public void mostraMensagem(String str) {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(InserirAgedamentoActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}