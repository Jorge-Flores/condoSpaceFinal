package com.example.condospace2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MenuActivity extends AppCompatActivity {
    Button btInserirAgendamento, btListarAgendamento;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);

            btListarAgendamento = findViewById(R.id.btVisualizarAgendamentos);
            btInserirAgendamento = findViewById(R.id.btIncluirAgendamento);
            btInserirAgendamento.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View argsO) {
                    Intent inserirAgendamentoActivity = new Intent(MenuActivity.this, InserirAgedamentoActivity.class);
                    MenuActivity.this.startActivity(inserirAgendamentoActivity);
                }
            });

            btListarAgendamento.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View argsO) {
                    Intent listarAgendamentoActivity = new Intent(MenuActivity.this, ListaAgendamentosActivity.class);
                    MenuActivity.this.startActivity(listarAgendamentoActivity);
                }
            });
    }
}